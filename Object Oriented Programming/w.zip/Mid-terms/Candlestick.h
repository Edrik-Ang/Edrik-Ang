#pragma once
#include <string>


class Candlestick{
    public:
    //time key identify the candle bucket
    //E.g 1980 for yearly, 1980-01 for monthly or 1980-01-01 for daily.
    // 


        double open;
        double close;
        double high;
        double low;

    Candlestick(
                double o,
                double c,
                double h, 
                double l):
                open(o),
                close(c),
                high(h), 
                low(l) {}
       
                // void print() const; 
};
